
public abstract class User
{
    protected String name;//isws thelei private auta ta dio meli 
    protected String email;     
}